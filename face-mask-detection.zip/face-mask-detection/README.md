# face-mask-detection

This project contains the code which is analyzing whether the person in front of web came have mask or not
